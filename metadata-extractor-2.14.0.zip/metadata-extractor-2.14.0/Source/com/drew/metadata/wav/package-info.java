/**
 * Contains classes for the extraction and modelling of WAV file metadata.
 */
package com.drew.metadata.wav;
