/**
 * Contains classes for the extraction and modelling of GIF file metadata.
 *
 * @since 2.7.0
 */
package com.drew.metadata.gif;
