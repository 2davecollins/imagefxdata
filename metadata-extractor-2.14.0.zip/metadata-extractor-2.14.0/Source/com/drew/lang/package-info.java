/**
 * Contains classes of generic utility.
 */
package com.drew.lang;
